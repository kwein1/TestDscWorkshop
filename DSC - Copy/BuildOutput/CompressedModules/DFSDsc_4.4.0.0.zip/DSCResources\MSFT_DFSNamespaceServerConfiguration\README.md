# Description

This resource is used to configure DFS Namespace server settings. This is a
single instance resource that can only be used once in a DSC Configuration.
