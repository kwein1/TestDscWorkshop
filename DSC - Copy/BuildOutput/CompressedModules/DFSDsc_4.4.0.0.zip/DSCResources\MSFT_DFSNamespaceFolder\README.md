# Description

This resource is used to create, edit or remove folders from DFS namespaces.
When a target is the last target in a namespace folder, the namespace folder
itself will be removed.
