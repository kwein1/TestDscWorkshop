# Description

This resource is used to configure DFS Replication Group folders.
This is an optional resource, and only needs to be used if any of the following
folder properties need to be set:

- Description
- FilenameToExclude
- DirectoryNameToExclude

In most cases just setting the Folders property in the DFSReplicationGroup
resource will be acceptable.
