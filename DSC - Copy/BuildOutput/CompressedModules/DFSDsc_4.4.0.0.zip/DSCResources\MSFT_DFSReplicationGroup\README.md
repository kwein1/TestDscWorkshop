# Description

This resource is used to create, edit or remove DFS Replication Groups. If used
to create a Replication Group it should be combined with the
DFSReplicationGroupMembership resources.
