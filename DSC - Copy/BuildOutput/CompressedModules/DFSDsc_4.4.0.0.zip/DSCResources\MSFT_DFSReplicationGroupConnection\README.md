# Description

This resource is used to create, edit and remove DFS Replication Group
connections. This resource should ONLY be used if the Topology parameter in the
Resource Group is set to Manual.
